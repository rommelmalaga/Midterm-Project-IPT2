import '../App.css';
import Button from './Button';

function Content() {
    
    return (
        <div className='content'>
            <h3>Left SideBar</h3>
        </div>
    )
}
export default Content;