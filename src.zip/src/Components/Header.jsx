import '../App.css';


function Header() {

    return(
        <div className='header'>
            <header className='head'>
                <nav>
                    <a href=""> 1 </a>
                    <a href=""> 2 </a>
                    <a href=""> 3 </a>
                    <a href=""> 4 </a>
                </nav>
            </header>
        </div>
    )
}
export default Header;