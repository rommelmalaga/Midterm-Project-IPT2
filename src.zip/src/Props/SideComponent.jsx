import React from 'react';

function SideComponent(props){
    return(
         
        <div className='bottom'>
                {props.sidehandler}
            </div>
     
    )
}

export default SideComponent;