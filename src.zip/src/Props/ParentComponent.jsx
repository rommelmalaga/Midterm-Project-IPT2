import React from 'react';
import ChildComponent from './ChildComponent';
import DataComponent from './DataComponent';
import GroceryList from './GroceryList';

function ParentComponent(){
    const dynamicValue = "Top SideBar"
    const dataVal = "This is a data value."
    const sideBar ="Bottom Sidebar"
    
    let groceryList = ["1","2", "3", "4"]
    return(
        <div>
            <ChildComponent 
            subjectNameHandler={dynamicValue}/>
            <DataComponent 
            datavalue={dataVal}/>
            <DataComponent 
            sidehandler={sideBar}/>

            <GroceryList groceryListData ={groceryList} />
        </div>

    )
}

export default ParentComponent;