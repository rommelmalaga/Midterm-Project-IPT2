import React from 'react';

function DataComponent(props){
    return(
        <div className='left'>
        <div className='right'>
            {props.datavalue}
        </div>
        <div className='bottom'>
                {props.sidehandler}
            </div>
        </div>

    )
}

export default DataComponent;