import React from 'react';

function ChildComponent(props){
    return(
        <div className='side'>
            {props.subjectNameHandler}
            
        </div>

    )
}

export default ChildComponent;