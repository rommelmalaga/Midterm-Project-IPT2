import React, { useState, } from "react";
import "../App.css";

function App() {
    const [inputText, setInputText] = useState("");
  const [items, setItems] = useState([]);

  function handleChange(event) {
    const newValue = event.target.value;
    setInputText(newValue);
  }

  function addItems() {
    setItems((prevValue) => [...prevValue, inputText]);
    setInputText("");
  }


  function deleteItem(index) {
    const updatedItems = [...items];
    updatedItems.splice(index, 1);
    setItems(updatedItems);
  }


return (
    <div className="contain">
      <div className="head">
        <h2>To-Do List</h2>
      </div>
      <div className="forms">
        <input onChange={handleChange} type="text" placeholder="Add Task" value={inputText} />
        <button className="bot" onClick={addItems}>
          <span>Add Tasks</span> 
        </button>
      </div>
      <div>
        <ul>
          {items.map((todoItem, index) => (
            <li key={index}>
              <span>{todoItem}</span>
              <button className="move" onClick={() => deleteItem(index)}>
                <span className="del">Delete</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
export default App;